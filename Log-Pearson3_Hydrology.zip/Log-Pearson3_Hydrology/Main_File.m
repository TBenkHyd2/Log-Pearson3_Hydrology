clc; close all; clear all;
% Log Pearson III Ditribution For Differents Return Periods 
% By  T. Benkaci & N.Dechemi Copyright 2020 --- According USGS Bulletin 17B

%-------------------------------------------------------------------------
PP = xlsread('File_Data.xlsx'); %File data in excel

D=PP(1:end,1:1); % the first column is the Years
P=PP(1:end,2:2); % the second Column is the Data: Observed Annual Rainfall

n=length(P); m=mean(P);s=std(P);

%Log Pearson3 Distribution use K-factor that depends on skew coefficient(Cs):  
%1-use this formula according skewness of K.Pearson:
m1=mean(log10(P)); s1=std(log10(P));
data=log10(P);
for i=1:n,
    CS1(i)=((data(i)-m1)/s1).^3;
end
Cs2=n/((n-1)*(n-2))*sum(CS1); 

%2-use this formula instead:

Cs1=skewness(log10(P)); 

%Choose Formula: Cs1 or Cs2
Cs=Cs2;

% sort  data 
y=sort(P);

%Calculate plot position according
j=1; %  plot position according Hazen ; 2=Cunane instead.
if j==1;
 %  Probability Plot Position Formula---Frequence Empirique--Methode de HAZEN
    for i=1:n 
    f(i)=(i-0.5)/(n);
    end
elseif j==3;
 %  Probability Plot Position Formula---Frequence Empirique--Methode CUNANE
    for i=1:n 
    f(i)=(i-0.4)/(n+0.2);
    end
end

% The main file of calculations of Log Pearson 3 (p-code)
[XP,Cs, x1, x2, x3,lb,ub,X,X_Sim] = LogPearson3(P,Cs,y,m,s,f,n);
